from base_datos import BaseDatos
from autenticacion import Autenticacion
import sqlite3

class AdministracionMenu:
    baseDatos = None
    autenticacion = None
    
    def __init__(self):
        self.baseDatos = BaseDatos('clientesDB.db')
        self.autenticacion = Autenticacion()
        if self.baseDatos.verificarBaseDatosExiste():
            self.autenticacion.verificarAutenticacion()
        else:
            self.baseDatos.crearBaseDatos()
            self.baseDatos.crearTablaProyectoFinal()
            self.autenticacion.verificarAutenticacion()

    def mostrarListaMenus(self):
        try:
            conexion = self.baseDatos.abrirConexion()
            cursor = conexion.cursor()
            cursor.execute("SELECT * FROM menu")     
            menus = cursor.fetchall()
            if len(menus) > 0:
                print("Lista de pedidos disponibles: ")
                print("------------------------------------")
                for clave,nombre_menu, precio in menus:
                    print('id: {}, nombre del pedido: {}, precio: {}'
                        .format(clave, nombre_menu, precio))
                print("------------------------------------")
            else:
                print("No hay clientes que mostrar")
                print("------------------------------------")
        except sqlite3.Error as error:
            print("Error al mostrar los datos de la tabla clientes", error)
        finally:
            if conexion:
                cursor.close()
                conexion.close()

    def agregarMenu(self):
        try:
            conexion = self.baseDatos.abrirConexion()
            cursor = conexion.cursor()
            nombre_menu, precio = self.ingresarDatosMenu()
            valores = (nombre_menu, precio)
            sql = ''' INSERT INTO menu(nombre,precio)
                    VALUES(?,?) '''
                    
            cursor.execute(sql,valores)
            conexion.commit()
            print("Datos guardados correctamente")
            print("------------------------------------")
        except sqlite3.Error as e:
            print('Error al intentar insertar los datos: {}'.format(e))
        finally:
            if conexion:
                cursor.close()
                conexion.close()
    
    def modificarMenu(self):
        try:
            conexion = self.baseDatos.abrirConexion()
            cursor = conexion.cursor()
            
            cursor.execute("SELECT * FROM menu")     
            menus = cursor.fetchall()
            if len(menus) > 0:                
                print("Lista de clientes para modificar:")
                self.mostrarListaMenus()
                print("----------------------------------")
                id_menu = self.ingresarID("Ingresa el id del cliente a modificar \n")                
                encontrar_menu = cursor.execute("SELECT * FROM menu WHERE clave = ?", (id_menu,))    
                menu = encontrar_menu.fetchone()
                if menu :
                    nombre_menu, precio = self.ingresarDatosMenu()
                    sql = ''' UPDATE menu SET nombre = ?, precio = ? WHERE clave = ? '''
                    datos_menu = (nombre_menu, precio,id_menu)
                    cursor.execute(sql,datos_menu)
                    conexion.commit()
                    print("Registro modificado correctamente")
                    print("------------------------------------")
                else:
                    print("No hay registro con ese id")
                    print("------------------------------------")
            else:  
                print("No hay clientes para modificar")
                print("------------------------------------")
        except sqlite3.Error as e:
            print('Error al intentar modificar el registro: {}'.format(e))
        finally:
            if conexion:
                cursor.close()
                conexion.close()
    
    def eliminarMenu(self):
        try:
            conexion = self.baseDatos.abrirConexion()
            cursor = conexion.cursor()
            cursor.execute("SELECT * FROM menu")     
            menus = cursor.fetchall()
            if len(menus) > 0:            
                print("Lista de menus para eliminar:")
                self.mostrarListaMenus()
                print("------------------------------------")
                id_menu = self.ingresarID("Ingresa el id del cliente a eliminar \n")                
                encontrar_menu = cursor.execute("SELECT * FROM menu WHERE clave = ?", (id_menu,))     
                if len(encontrar_menu.fetchall()) == 1:
                    sql = ''' DELETE FROM menu WHERE clave = ? '''
                    cursor.execute(sql,(id_menu,))
                    conexion.commit()
                    print("Registro eliminado correctamente")
                    print("------------------------------------")
                else:
                    print("No hay registro con ese id")
                    print("------------------------------------")
            else:  
                print("No hay clientes para eliminar")
                print("------------------------------------")
        except sqlite3.Error as e:
            print('Error al intentar eliminar el registro: {}'.format(e))
        finally:
            if conexion:
                cursor.close()
                conexion.close()
    
    def ingresarID(self,mensaje):
        id_cliente = 0
        datos_incorrectos = True
        while datos_incorrectos:
            try:
                id_cliente = int(input( mensaje ))
                datos_incorrectos = False
            except Exception as e:
                print('Error al capturar el id del cliente: {}'.format(e))
                print('Intente de nuevo ingresar el id \n')
                datos_incorrectos = True
        return id_cliente
    
    def ingresarDatosMenu(self):
        datos_incorrectos = True
        while datos_incorrectos:
            try:
                nombre_menu = input("Ingresa el nombre del pedido \n")
                precio = float(input("Ingresa su precio \n"))
                datos_incorrectos = False
            except Exception as e:
                print('Error al capturar un dato: {}'.format(e))
                print('Intente de nuevo ingresar los datos \n')
                datos_incorrectos = True
        return nombre_menu, precio