from base_datos import BaseDatos
from autenticacion import Autenticacion
import sqlite3

class AdministracionPedido:
    baseDatos = None
    autenticacion = None
    
    def __init__(self):
        self.baseDatos = BaseDatos('clientesDB.db')
        self.autenticacion = Autenticacion()
        if self.baseDatos.verificarBaseDatosExiste():
            self.autenticacion.verificarAutenticacion()
        else:
            self.baseDatos.crearBaseDatos()
            self.baseDatos.crearTablaProyectoFinal()
            self.autenticacion.verificarAutenticacion()

    def mostrarListaPedidos(self):
        try:
            conexion = self.baseDatos.abrirConexion()
            cursor = conexion.cursor()
            cursor.execute("SELECT * FROM pedidos")     
            pedidos = cursor.fetchall()
            if len(pedidos) > 0:
                print("Lista de pedidos disponibles: ")
                print("------------------------------------")
                for clave,cliente, producto , precio in pedidos:
                    print('id: {}, nombre del cliente: {}, nombre producto: {}, precio: {}'
                        .format(clave, cliente, producto, precio))
                print("------------------------------------")
            else:
                print("No hay clientes que mostrar")
                print("------------------------------------")
        except sqlite3.Error as error:
            print("Error al mostrar los datos de la tabla clientes", error)
        finally:
            if conexion:
                cursor.close()
                conexion.close()

    def agregarPedido(self):
        try:
            conexion = self.baseDatos.abrirConexion()
            cursor = conexion.cursor()
            cliente, producto, precio = self.ingresarDatosCliente()
            valores = (cliente, producto, precio)
            sql = ''' INSERT INTO pedidos(cliente, producto, precio)
                    VALUES(?,?,?) '''
                    
            cursor.execute(sql,valores)
            conexion.commit()
            print("Datos guardados correctamente")
            print("------------------------------------")
        except sqlite3.Error as e:
            print('Error al intentar insertar los datos: {}'.format(e))
        finally:
            if conexion:
                cursor.close()
                conexion.close()
    
#aqui inicia la definición de esta funcion nueva
    def agregarPedido(self):
        try:
            conexion = self.baseDatos.abrirConexion()
            cursor = conexion.cursor()
            cliente, producto, precio = self.ingresarDatosPedido()
            valores = (cliente, producto, precio)
            sql = ''' INSERT INTO pedidos(cliente, producto, precio)
                    VALUES(?,?,?) '''
            cursor.execute(sql,valores)
            conexion.commit()
            print("Datos guardados correctamente")
            print("------------------------------------")
        except sqlite3.Error as e:
            print('Error al intentar insertar los datos: {}'.format(e))
        finally:
            if conexion:
                cursor.close()
                conexion.close()

#aqui termina la definición

    def modificarPedido(self):
        try:
            conexion = self.baseDatos.abrirConexion()
            cursor = conexion.cursor()
            
            cursor.execute("SELECT * FROM pedidos")     
            pedidos = cursor.fetchall()
            if len(pedidos) > 0:                
                print("Lista de pedidos para modificar:")
                self.mostrarListaPedidos()
                print("----------------------------------")
                id_pedido = self.ingresarID("Ingresa el id del pedido a modificar \n")                
                encontrar_pedido = cursor.execute("SELECT * FROM pedidos WHERE pedido = ?", (id_pedido,))    
                pedido = encontrar_pedido.fetchone()
                if pedido :
                    cliente, producto, precio = self.ingresarDatosPedido()
                    sql = ''' UPDATE pedidos SET cliente = ?, producto = ?, precio = ? WHERE pedido = ? '''
                    datos_pedido = (cliente, producto, precio, id_pedido)
                    cursor.execute(sql,datos_pedido)
                    conexion.commit()
                    print("Registro modificado correctamente")
                    print("------------------------------------")
                else:
                    print("No hay registro con ese id")
                    print("------------------------------------")
            else:  
                print("No hay clientes para modificar")
                print("------------------------------------")
        except sqlite3.Error as e:
            print('Error al intentar modificar el registro: {}'.format(e))
        finally:
            if conexion:
                cursor.close()
                conexion.close()
    
    def eliminarPedido(self):
        try:
            conexion = self.baseDatos.abrirConexion()
            cursor = conexion.cursor()
            cursor.execute("SELECT * FROM pedidos")     
            pedidos = cursor.fetchall()
            if len(pedidos) > 0:            
                print("Lista de pedidos para eliminar:")
                self.mostrarListaPedidos()
                print("------------------------------------")
                id_pedido = self.ingresarID("Ingresa el id del pedido a eliminar \n")                
                encontrar_pedido = cursor.execute("SELECT * FROM pedidos WHERE pedido = ?", (id_pedido,))
                if len(encontrar_pedido.fetchall()) == 1:
                    sql = ''' DELETE FROM pedidos WHERE pedido = ? '''
                    cursor.execute(sql,(id_pedido,))
                    conexion.commit()
                    print("Registro eliminado correctamente")
                    print("------------------------------------")
                else:
                    print("No hay registro con ese id")
                    print("------------------------------------")
            else:  
                print("No hay clientes para eliminar")
                print("------------------------------------")
        except sqlite3.Error as e:
            print('Error al intentar eliminar el registro: {}'.format(e))
        finally:
            if conexion:
                cursor.close()
                conexion.close()
    
    def ingresarID(self,mensaje):
        id_cliente = 0
        datos_incorrectos = True
        while datos_incorrectos:
            try:
                id_cliente = int(input( mensaje ))
                datos_incorrectos = False
            except Exception as e:
                print('Error al capturar el id del cliente: {}'.format(e))
                print('Intente de nuevo ingresar el id \n')
                datos_incorrectos = True
        return id_cliente
    
    def ingresarDatosPedido(self):
        datos_incorrectos = True
        while datos_incorrectos:
            try:
                cliente = input("Ingresa el nombre del cliente \n")
                producto = input("Ingresa el nombre del producto \n")
                precio = float(input("Ingresa el precio del producto \n"))
                datos_incorrectos = False
            except Exception as e:
                print('Error al capturar un dato: {}'.format(e))
                print('Intente de nuevo ingresar los datos \n')
                datos_incorrectos = True
        return cliente, producto, precio
    
    def generar_ticket(self):
            conexion = self.baseDatos.abrirConexion()
            cursor = conexion.cursor()
            
            cursor.execute("SELECT * FROM pedidos")     
            pedidos = cursor.fetchall()
            if len(pedidos) > 0:                
                print("Lista de pedidos para obtener un ticket:")
                self.mostrarListaPedidos()
                print("----------------------------------")
                id_pedido = self.ingresarID("Ingresa el ID del pedido para generar el Ticket \n")                
                encontrar_pedido = cursor.execute("SELECT * FROM pedidos WHERE pedido = ?", (id_pedido,))    
                pedido = encontrar_pedido.fetchone()
                if pedido :
                    with open(f'ticket_{id_pedido}.txt', 'w') as infoTkt:
                        infoTkt.write(f"Ticket del Pedido\n")
                        infoTkt.write(f"ID del Pedido: {id_pedido}\n")
                        infoTkt.write(f"Cliente: {pedido[1]}\n")
                        infoTkt.write(f"Producto: {pedido[2]} \n")
                        infoTkt.write(f"Precio: ${pedido[3]}\n")
                    print(f"Ticket generado: ticket_{id_pedido}.txt")
                else:
                    print("No hay registro con ese id")
                    print("------------------------------------")
            else:  
                print("No hay pedidos para mostrr")
                print("------------------------------------")

            if conexion:
                cursor.close()
                conexion.close()










            