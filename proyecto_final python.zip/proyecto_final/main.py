from clientes import AdministracionCliente
from pedidos import AdministracionPedido
from menu import AdministracionMenu
from base_datos import BaseDatos
from autenticacion import Autenticacion
import sqlite3

menuPedido = AdministracionCliente

def seleccionar_opcion():
    iteracion=0
    while iteracion==0:
        print("")
        print("""
         BIENVENIDOS AL SISTEMA DE COMIDAS Python
                    MENU PRINCIPAL

                    a. Pedidos
                    b. Clientes
                    c. Menu
                    d. Salir
            
        """)    

        print("")

        opcion = (input("¿Que opción deseas seleccionar a, b, c, d:? "))
        if opcion == "a":
            print("")
            manejo_pedidos()
        elif opcion == "b":
            print("")
            manejo_clientes()
        elif opcion == "c":
            print("")
            manejo_menu()
        elif opcion == "d":
            iteracion=1
            print("")
            print("Seleccionaste la opción: d Salir.")
            print("Hasta luego. Termina la sesion ")
            print("")
        else:
            print("")
            print("Opción no valida, vuelve a seleccionar")

def manejo_pedidos():
        inventario = AdministracionPedido()
        print("------------------------------------")
        salir_programa = False
        while not salir_programa:
            print(""" 
                     Menú de PEDIDOS
                  
                1.- Mostrar lista de pedidos
                2.- Agregar pedido
                3.- Modificar pedido
                4.- Cancelar pedido
                5.- Generar recibo 
                6.- Salir del menu de pedidos
                """)
            opcion = int(input("Indica una opción del menú: "))
            if opcion == 1:
                inventario.mostrarListaPedidos()
            elif opcion == 2:
                inventario.agregarPedido()
            elif opcion == 3:
                inventario.modificarPedido()
            elif opcion == 4:
                inventario.eliminarPedido()
            elif opcion == 5:
                inventario.generar_ticket()   
            elif opcion > 6:
                print("")
                print("Opción no valida, vuelve a seleccionar")
            if opcion == 6:
                print(" ")
                print("Salida del menu de PEDIDOS.")
                salir_programa = True

def manejo_clientes():
        inventario = AdministracionCliente()
        print("------------------------------------")
        salir_programa = False
        while not salir_programa:
            print(""" 
                     Menú de CLIENTES
                  
                1.- Mostrar lista de clientes
                2.- Agregar cliente
                3.- Modificar cliente
                4.- Eliminar cliente
                5.- Salir del menu de clientes
                """)
            opcion = int(input("Indica una opción del menú: "))
            if opcion == 1:
                inventario.mostrarListaClientes()
            elif opcion == 2:
                inventario.agregarCliente()
            elif opcion == 3:
                inventario.modificarCliente()
            elif opcion == 4:
                inventario.eliminarCliente()
            if opcion == 5:
                print(" ")
                print("Salida del menus de CLIENTES ")
                salir_programa = True

def manejo_menu():
        inventario = AdministracionMenu()
        print("------------------------------------")
        salir_programa = False
        while not salir_programa:
            print(""" 
                     Menú de PRODUCTOS
                  
                1.- Mostrar lista de producto
                2.- Agregar producto
                3.- Modificar producto
                4.- Eliminar producto
                5.- Salir del menu de productos
                """)
            opcion = int(input("Indica una opción del menú: "))
            if opcion == 1:
                inventario.mostrarListaMenus()
            elif opcion == 2:
                inventario.agregarMenu()
            elif opcion == 3:
                inventario.modificarMenu()
            elif opcion == 4:
                inventario.eliminarMenu()
            if opcion == 5:
                print(" ")
                print("Salida del menu de PRODUCTOS ")
                salir_programa = True

#sistema_inventario = Aplicacion()   

seleccionar_opcion()
