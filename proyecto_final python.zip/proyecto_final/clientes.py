from base_datos import BaseDatos
from autenticacion import Autenticacion
import sqlite3

class AdministracionCliente:
    baseDatos = None
    autenticacion = None
    
    def __init__(self):
        self.baseDatos = BaseDatos('clientesDB.db')
        self.autenticacion = Autenticacion()
        if self.baseDatos.verificarBaseDatosExiste():
            self.autenticacion.verificarAutenticacion()
        else:
            self.baseDatos.crearBaseDatos()
            self.baseDatos.crearTablaProyectoFinal()
            self.autenticacion.verificarAutenticacion()

    def mostrarListaClientes(self):
        try:
            conexion = self.baseDatos.abrirConexion()
            cursor = conexion.cursor()
            cursor.execute("SELECT * FROM clientes")     
            clientes = cursor.fetchall()
            if len(clientes) > 0:
                print("Lista de clientes disponibles: ")
                print("------------------------------------")
                for clave,nombre_cliente,direccion,correo_electronico,telefono in clientes:
                    print('id: {}, nombre del cliente: {}, direccion: {}, correo_electronico: {}, telefono: {}'
                        .format(clave, nombre_cliente, direccion, correo_electronico, telefono))
                print("------------------------------------")
            else:
                print("No hay clientes que mostrar")
                print("------------------------------------")
        except sqlite3.Error as error:
            print("Error al mostrar los datos de la tabla clientes", error)
        finally:
            if conexion:
                cursor.close()
                conexion.close()

    def agregarCliente(self):
        try:
            conexion = self.baseDatos.abrirConexion()
            cursor = conexion.cursor()
            nombre_cliente,direccion,correo_electronico,telefono = self.ingresarDatosCliente()
            valores = (nombre_cliente, direccion, correo_electronico, telefono)
            sql = ''' INSERT INTO clientes(nombre,direccion, correo_electronico, telefono)
                    VALUES(?,?,?,?) '''
                    
            cursor.execute(sql,valores)
            conexion.commit()
            print("Datos guardados correctamente")
            print("------------------------------------")
        except sqlite3.Error as e:
            print('Error al intentar insertar los datos: {}'.format(e))
        finally:
            if conexion:
                cursor.close()
                conexion.close()
    
    def modificarCliente(self):
        try:
            conexion = self.baseDatos.abrirConexion()
            cursor = conexion.cursor()
            
            cursor.execute("SELECT * FROM clientes")     
            clientes = cursor.fetchall()
            if len(clientes) > 0:                
                print("Lista de clientes para modificar:")
                self.mostrarListaClientes()
                print("----------------------------------")
                id_cliente = self.ingresarID("Ingresa el id del cliente a modificar \n")                
                encontrar_cliente = cursor.execute("SELECT * FROM clientes WHERE clave = ?", (id_cliente,))    
                cliente = encontrar_cliente.fetchone()
                if cliente :
                    nombre_cliente,direccion,correo_electronico,telefono = self.ingresarDatosCliente()
                    sql = ''' UPDATE clientes SET nombre = ?, direccion = ?, correo_electronico = ?, telefono = ? WHERE clave = ? '''
                    datos_cliente = (nombre_cliente,direccion,correo_electronico,telefono,id_cliente)
                    cursor.execute(sql,datos_cliente)
                    conexion.commit()
                    print("Registro modificado correctamente")
                    print("------------------------------------")
                else:
                    print("No hay registro con ese id")
                    print("------------------------------------")
            else:  
                print("No hay clientes para modificar")
                print("------------------------------------")
        except sqlite3.Error as e:
            print('Error al intentar modificar el registro: {}'.format(e))
        finally:
            if conexion:
                cursor.close()
                conexion.close()
    
    def eliminarCliente(self):
        try:
            conexion = self.baseDatos.abrirConexion()
            cursor = conexion.cursor()
            cursor.execute("SELECT * FROM clientes")     
            clientes = cursor.fetchall()
            if len(clientes) > 0:            
                print("Lista de clientes para eliminar:")
                self.mostrarListaClientes()
                print("------------------------------------")
                id_cliente = self.ingresarID("Ingresa el id del cliente a eliminar \n")                
                encontrar_cliente = cursor.execute("SELECT * FROM clientes WHERE clave = ?", (id_cliente,))     
                if len(encontrar_cliente.fetchall()) == 1:
                    sql = ''' DELETE FROM clientes WHERE clave = ? '''
                    cursor.execute(sql,(id_cliente,))
                    conexion.commit()
                    print("Registro eliminado correctamente")
                    print("------------------------------------")
                else:
                    print("No hay registro con ese id")
                    print("------------------------------------")
            else:  
                print("No hay clientes para eliminar")
                print("------------------------------------")
        except sqlite3.Error as e:
            print('Error al intentar eliminar el registro: {}'.format(e))
        finally:
            if conexion:
                cursor.close()
                conexion.close()
    
    def ingresarID(self,mensaje):
        id_cliente = 0
        datos_incorrectos = True
        while datos_incorrectos:
            try:
                id_cliente = int(input( mensaje ))
                datos_incorrectos = False
            except Exception as e:
                print('Error al capturar el id del cliente: {}'.format(e))
                print('Intente de nuevo ingresar el id \n')
                datos_incorrectos = True
        return id_cliente
    
    def ingresarDatosCliente(self):
        datos_incorrectos = True
        while datos_incorrectos:
            try:
                nombre_cliente = input("Ingresa el nombre del cliente \n")
                direccion = input("Ingresa la direccion del cliente \n")
                correo_electronico = input("Ingresa su correo electronico \n")
                telefono = float(input("Ingresa su telefono \n"))
                datos_incorrectos = False
            except Exception as e:
                print('Error al capturar un dato: {}'.format(e))
                print('Intente de nuevo ingresar los datos \n')
                datos_incorrectos = True
        return nombre_cliente, direccion, correo_electronico, telefono